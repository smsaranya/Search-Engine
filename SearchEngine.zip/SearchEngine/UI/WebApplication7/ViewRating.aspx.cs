﻿ using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
//using System.Data.SqlClient;

namespace WebApplication7
{
    public partial class ViewRating : System.Web.UI.Page
    {
        public SqlCommand Cmd = new SqlCommand();
        public SqlConnection cnn = new SqlConnection();
        string con_QSR = ConfigurationManager.ConnectionStrings["SearchEngineConnectionString"].ToString();
        String id_val;
        protected void Page_Load(object sender, EventArgs e)
        {
            id_val = Request.QueryString["id"];
            BindGrid();
        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            BindGrid();
            // Add Fake Delay to simulate long running process.
            System.Threading.Thread.Sleep(2000);
            //LoadCustomers();



        }


        protected void BindGrid()
        {
            try
            {
               

                cnn = new SqlConnection(con_QSR);
                cnn.Open();
                String qry;
                

                    

                    //  Response.Write("<script type=text/javascript>alert('" + search_condition + "');</script>");
                    qry = "select id,(select fname as name from SE_Vendor_Registration where id =vendor_id),rating,comments from SE_Rating where  vendor_id='" + id_val+"' ";
                    //   qry = "select * from SE_Vendor_Registration";


                

                SqlDataAdapter da = new SqlDataAdapter(qry, cnn);
                //DataTable dt = new DataTable();
                DataSet dt = new DataSet();
                da.Fill(dt);
                GridView1.DataSource = dt;
                GridView1.DataBind();
                GridView1.ForeColor = System.Drawing.Color.Red;
                /* Cmd.Connection = cnn;
                 Cmd.CommandText = "select * from SE_User_Registration";
                 RepeatInformation.DataSource = Cmd.ExecuteReader();
                 RepeatInformation.DataBind();*/

                cnn.Close();

            }
            catch (Exception ex)
            {
                Response.Write("<script type=text/javascript>alert('" + ex.Message + "');</script>");
                cnn.Close();
            }
        }
        protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            BindGrid();
        }

       
    }
}