﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;


namespace WebApplication7
{
    public partial class forgot_password : System.Web.UI.Page
    {
        public SqlCommand Cmd = new SqlCommand();
        public SqlCommand Cmd1 = new SqlCommand();
        public SqlConnection cnn = new SqlConnection();
        string con_QSR = ConfigurationManager.ConnectionStrings["SearchEngineConnectionString"].ToString();
        static Random random = new Random();
        string Body = "";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            try
            {
                String email1 = email.Text.Trim();
                cnn = new SqlConnection(con_QSR);
                cnn.Open();
                String qry = "select * from SE_User_Registration where email_id='" + email1 + "'";
                SqlCommand cmd = new SqlCommand(qry, cnn);
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    err_message.Text = "";
                    MailMessage mail = new MailMessage();
                    mail.To.Add(email1);
                    mail.From = new MailAddress("smsaranya@gmail.com");
                    mail.Subject = "Email using Gmail";
                    Body = Convert.ToString(random.Next(10, 200));
                    mail.Body = "Your New Password is "+Body;
                    SmtpClient smtp = new SmtpClient();
                    smtp.Host = "smtp.gmail.com"; //Or Your SMTP Server Address
                    smtp.Port = 587;
                    smtp.UseDefaultCredentials = false;
                    smtp.Credentials = new System.Net.NetworkCredential
                    ("smsaranya@gmail.com", "strawberry@123");

                    //Or your Smtp Email ID and Password
                    smtp.EnableSsl = true;
                    smtp.Send(mail);
                    
                    err_message.ForeColor =System.Drawing.Color.Green;
                    err_message.Text = "Password sent to your registered email id.";
                    sdr.Close();
                   
                      
                }
                else
                {

                    err_message.ForeColor = System.Drawing.Color.Red;
                    err_message.Text = "Email ID does not exist.Please register to login.";
                    

                }
                String qry1 = "update SE_user_registration set password='" + EnryptString(Body) + "' where email_id='" + email1 + "'";
                Cmd1 = new SqlCommand(qry1, cnn);
                Cmd1.ExecuteNonQuery();
                cnn.Close();

            }
            catch (Exception ex)
            {
                Response.Write("<script type=text/javascript>alert('" + ex.Message + "');</script>");
                cnn.Close();
            }
        }
        public string EnryptString(string strEncrypted)
        {
            byte[] b = System.Text.ASCIIEncoding.ASCII.GetBytes(strEncrypted);
            string encrypted = Convert.ToBase64String(b);
            return encrypted;
        }  
    }
}