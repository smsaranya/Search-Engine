﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using System.IO;

namespace WebApplication7
{
    public partial class Login : System.Web.UI.Page
    {
        public SqlCommand Cmd = new SqlCommand();
        public SqlConnection cnn = new SqlConnection();
        string con_QSR = ConfigurationManager.ConnectionStrings["SearchEngineConnectionString"].ToString();

        protected void Page_Load(object sender, EventArgs e)
        {

        }


        protected void btnlogin_Click(object sender, EventArgs e)
        {
            try
            {
                String email1 = email.Text.Trim();
                String pass = pwd.Text.Trim();
                String user_type = DropDownList1.Text.Trim();
                //  Response.Write("<script type=text/javascript>alert('" + DecryptString(pass) + "');</script>");

                cnn = new SqlConnection(con_QSR);
                cnn.Open();
                String enc_pass;
                
                String qry = "";
                if (user_type.Equals("user"))
                {
                    enc_pass = EnryptString(pass);
                    //Response.Write("<script type=text/javascript>alert('" + enc_pass + "');</script>");
                    qry = "select * from SE_User_Registration where email_id='" + email1 + "' and password='" + enc_pass + "' and custom1='user'";

                }
                else if (user_type.Equals("admin"))
                {
                    enc_pass = EnryptString(pass);
                    qry = "select * from SE_User_Registration where email_id='" + email1 + "' and password='" + enc_pass + "' and custom1='admin'";
                     //Response.Write("<script type=text/javascript>alert('" + enc_pass + "');</script>");
                }
                else if (user_type.Equals("vendor"))
                {
                    enc_pass = (pass);
                    qry = "select * from SE_Vendor_Registration where email_id='" + email1 + "' and password='" + enc_pass + "'";
                }
                    
                SqlCommand cmd = new SqlCommand(qry, cnn);
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    String email_id = sdr.GetValue(10).ToString().Trim();
                    Session["login_status"] = true;
                    Session["username"] = email.Text;
                    Session["usertype"] = user_type;
                    if (user_type.Equals("vendor"))
                    {
                        Session["mode"] = "edit";
                        Response.Redirect("~/Vendor_Registration.aspx?email="+email_id+"&mode=edit&test=1", false);

                    }
                    
                    else
                    { 
                        Response.Redirect("~/Home.aspx", false);
                    }
                }
                else
                {

                    alert.ForeColor = System.Drawing.Color.Red;
                    alert.Text = "Invalid Username or Password";
                    Session["login_status"] = false;

                }
                cnn.Close();

            }
            catch (Exception ex)
            {
                Response.Write("<script type=text/javascript>alert('" + ex.Message + "');</script>");
                cnn.Close();
            }
        }
        public string EnryptString(string strEncrypted)
        {
            byte[] b = System.Text.ASCIIEncoding.ASCII.GetBytes(strEncrypted);
            string encrypted = Convert.ToBase64String(b);
            return encrypted;
        }  
        public string base64Decode2(string sData)
        {
            System.Text.UTF8Encoding encoder = new System.Text.UTF8Encoding();
            System.Text.Decoder utf8Decode = encoder.GetDecoder();
            byte[] todecode_byte = Convert.FromBase64String(sData);
            int charCount = utf8Decode.GetCharCount(todecode_byte, 0, todecode_byte.Length);
            char[] decoded_char = new char[charCount];
            utf8Decode.GetChars(todecode_byte, 0, todecode_byte.Length, decoded_char, 0);
            string result = new String(decoded_char);
            return result;
        }
      /* public string Decrypt(string cipherText)
        {
            string EncryptionKey = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            cipherText = cipherText.Replace(" ", "+");
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] {  
            0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76  
        });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    cipherText = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return cipherText;
        }  */

        public string DecryptString(string encrString)
        {
            byte[] b;
            string decrypted;
          //  Response.Write("<script type=text/javascript>alert('" + encrString + "');</script>");
            try
            {
                b = Convert.FromBase64String(encrString);
                decrypted = System.Text.ASCIIEncoding.ASCII.GetString(b);
            }
            catch (FormatException fe)
            {
                decrypted = "";
              //  Response.Write("<script type=text/javascript>alert('exceprkifdf');</script>");
            }
            return decrypted;
        }  
    }
}