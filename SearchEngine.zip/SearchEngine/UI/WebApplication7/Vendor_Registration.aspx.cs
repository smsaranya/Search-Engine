﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Net.Mail;



namespace WebApplication7
{
    public partial class Vendor_Registration : System.Web.UI.Page
    {
        public SqlCommand Cmd = new SqlCommand();
        public SqlConnection cnn = new SqlConnection();
        string con_QSR = ConfigurationManager.ConnectionStrings["SearchEngineConnectionString"].ToString();
        String mode;
        String id1;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                String email_id = emailid.Text.Trim();
                
                mode = Request.QueryString["mode"];
                Session["mode"] = mode;
                id1 = Request.QueryString["email"];
               
                //Response.Write("<script type=text/javascript>alert('" + mode + "');</script>");
               // Response.Write("<script type=text/javascript>alert('njhjhj" + id1 + "');</script>");


                if (mode == "edit")
                {
                    cnn = new SqlConnection(con_QSR);
                    cnn.Open();
                    //Response.Write("<script type=text/javascript>alert('" + id1 + "');</script>");
                    String qry = "select * from SE_Vendor_Registration  where email_id='"+id1+"' and 1=1";
                    Cmd = new SqlCommand(qry,cnn);
                    SqlDataReader reader = Cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        fname.Text = (reader["fname"].ToString());
                        mname.Text = (reader["mname"].ToString());
                        lname.Text = (reader["lname"].ToString());
                        occup.Text = (reader["occupation"].ToString());
                        resaddr.Text = (reader["res_address"].ToString());
                        offaddr.Text = (reader["off_address"].ToString());
                        rescon.Text = (reader["res_contact"].ToString());
                        offcon.Text = (reader["off_contact"].ToString());
                        emailid.Text = (reader["email_id"].ToString());
                        pass.Text = (reader["password"].ToString());
                        honorific.Text = (reader["honorific"].ToString());
                        Register.Text = "Update";


                    }
                   
                    reader.Close();
                    reader.Dispose();
                    cnn.Close();
                    cnn.Dispose();
                    Cmd.Dispose();

                }
            }
            
                   
            string EnryptString(string strEncrypted)
            {
                byte[] b = System.Text.ASCIIEncoding.ASCII.GetBytes(strEncrypted);
                string encrypted = Convert.ToBase64String(b);
                return encrypted;
            }
            string encrypt(string encryptString)
            {
                string EncryptionKey = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                byte[] clearBytes = Encoding.Unicode.GetBytes(encryptString);
                using (Aes encryptor = Aes.Create())
                {
                    Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] {
            0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76
        });
                    encryptor.Key = pdb.GetBytes(32);
                    encryptor.IV = pdb.GetBytes(16);
                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(clearBytes, 0, clearBytes.Length);
                            cs.Close();
                        }
                        encryptString = Convert.ToBase64String(ms.ToArray());
                    }
                }
                return encryptString;
            }

   
        }

        protected void Register_Click(object sender, EventArgs e)
        {
            String honorific1 = honorific.Text.Trim();
            String f_name = fname.Text.Trim();
            String m_name = mname.Text.Trim();
            String l_name = lname.Text.Trim();
            String occupation = occup.Text.Trim();
            String res_address = resaddr.Text.Trim();
            String off_address = offaddr.Text.Trim();
            String res_contact = rescon.Text.Trim();
            String off_contact = offcon.Text.Trim();
            String email_id = emailid.Text.Trim();
            String password = pass.Text.Trim();

            String mode1 = (Session["mode"].ToString()) ;
            if(mode1.Equals("") || mode1.Equals(null))
            {
                mode1 = Request.QueryString["mode"];
            }
                //Response.Write("<script type=text/javascript>alert('" + mode + "');</script>");
            if (mode1 == "edit")
            {
                cnn = new SqlConnection(con_QSR);
                
                cnn.Open();
                String qry = "update SE_Vendor_Registration set honorific='" + honorific1 + "',fname='" + f_name + "',mname='" + m_name + "',lname='" + l_name + "',occupation='" + occupation + "',res_address='" + res_address + "',off_address='" + off_address + "',res_contact='" + res_contact + "',off_contact='" + off_contact + "',password='" + password + "' where email_id='" + email_id + "'";
                Console.Write(qry);
                //Response.Write("<script type=text/javascript>alert('" + qry + "');</script>");

                Cmd = new SqlCommand(qry, cnn);
                Cmd.ExecuteNonQuery();
                //alert.ForeColor = System.Drawing.Color.Red;
                //alert.Text = "Record Saved Successfully";
               /* MailMessage mail = new MailMessage();
                mail.To.Add(email_id);
                mail.From = new MailAddress("smsaranya@gmail.com");
                mail.Subject = "Email using Gmail";
                //String Body = Convert.ToString(random.Next(10, 200));
                mail.Body = "Your Details Has Been Updated";
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com"; //Or Your SMTP Server Address
                smtp.Port = 587;
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new System.Net.NetworkCredential
                ("smsaranya@gmail.com", "strawberry@123");

                //Or your Smtp Email ID and Password
                smtp.EnableSsl = true;
                smtp.Send(mail); */
                cnn.Close();
                
                    string message = "Your details have been updated successfully.";
                
               
                string script = "window.onload = function(){ alert('";
                script += message;
                script += "');";
                script += "window.location = '";
                script += Request.Url.AbsoluteUri;
                script += "'; }";
                ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);
                System.Threading.Thread.Sleep(2000);

            }
            else
            {
                try
                {


                    cnn = new SqlConnection(con_QSR);
                    cnn.Open();
                    String qry = "insert into SE_Vendor_Registration(honorific,fname,mname,lname,occupation,res_address,off_address,res_contact,off_contact,email_id,password,created_by,created_on,updated_by,updated_on,custom0,custom1,custom2)  values('" + honorific1 + "','" + f_name + "','" + m_name + "','" + l_name + "','" + occupation + "','" + res_address + "','" + off_address + "','" + res_contact + "','" + off_contact + "','" + email_id + "','" + password + "','admin',GETDATE(),'','','','','')";
                    //Response.Write("<script type=text/javascript>alert('" + qry + "');</script>");

                    Cmd = new SqlCommand(qry, cnn);
                    Cmd.ExecuteNonQuery();
                    //alert.ForeColor = System.Drawing.Color.Red;
                    //alert.Text = "Record Saved Successfully";
                    cnn.Close();
                    string message = "Your details have been saved successfully.";
                    string script = "window.onload = function(){ alert('";
                    script += message;
                    script += "');";
                    script += "window.location = '";
                    script += Request.Url.AbsoluteUri;
                    script += "'; }";
                    ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);
                    System.Threading.Thread.Sleep(2000);


                }
                catch (Exception e1)
                {
                    //  Response.Redirect("~/Error.html");
                    alert.ForeColor = System.Drawing.Color.Red;
                    alert.Text = "Problem in Inserting the Record";
                }
            }
        }
    }
}

