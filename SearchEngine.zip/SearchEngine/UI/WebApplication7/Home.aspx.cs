﻿using System;using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
//using System.Data.SqlClient;

namespace WebApplication7
{
    public partial class Home : System.Web.UI.Page
    {
        public SqlCommand Cmd = new SqlCommand();
        public SqlConnection cnn = new SqlConnection();
        string con_QSR = ConfigurationManager.ConnectionStrings["SearchEngineConnectionString"].ToString();

        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            BindGrid();
            // Add Fake Delay to simulate long running process.
            System.Threading.Thread.Sleep(2000);
            //LoadCustomers();
        


        }

        protected void BindGrid()
        {
            try
            {
                String search_keyword_val = keyword.Text.Trim();
                String search_option_val = search_option.Text.Trim();
               
               // Response.Write("<script type=text/javascript>alert('" + search_keyword_val + "');</script>");
                //Response.Write("<script type=text/javascript>alert('" + search_option_val + "');</script>");
                cnn = new SqlConnection(con_QSR);
                cnn.Open();
                String qry;
                if(search_option_val=="Occupation")
                {
                  
                   // Response.Write("<script type=text/javascript>alert('test0');</script>");
                    qry = "select * from SE_Vendor_Registration where occupation='" + search_keyword_val + "'";
               }
                else
                {
                   
                   String search_condition= "%" + search_keyword_val + "%";
                  //  Response.Write("<script type=text/javascript>alert('" + search_condition + "');</script>");
                  qry = "select * from SE_Vendor_Registration where fname like '" + search_condition + "'";
                //   qry = "select * from SE_Vendor_Registration";
                   

               }
                
                SqlDataAdapter da = new SqlDataAdapter(qry, cnn);
                //DataTable dt = new DataTable();
                DataSet dt = new DataSet();
                da.Fill(dt);
                search_result.DataSource = dt;
                search_result.DataBind();
                search_result.ForeColor = System.Drawing.Color.Red;
                /* Cmd.Connection = cnn;
                 Cmd.CommandText = "select * from SE_User_Registration";
                 RepeatInformation.DataSource = Cmd.ExecuteReader();
                 RepeatInformation.DataBind();*/
              
                cnn.Close();

            }
            catch (Exception ex)
            {
                Response.Write("<script type=text/javascript>alert('" + ex.Message + "');</script>");
                cnn.Close();
            }
        }
        protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            search_result.PageIndex = e.NewPageIndex;
           BindGrid();
        }

        protected void RadioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}