﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication7
{
    public partial class SiteMaster : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Response.Write("<script type=text/javascript>alert('"+Session["username"]+"');</script>");
            if (Session["username"] != "" && Session["username"] != null)
            {
               
                loggedin.ForeColor = System.Drawing.Color.White;
                loggedin.Text = "Welcome "+Session["username"].ToString();
                loginlink.Visible = false;
                registerlink.Visible = false;

                logoutlink.ForeColor = System.Drawing.Color.White;
                logoutlink.Visible = true;
                //Response.Write("<script type=text/javascript>alert('" + Session["username"] + "');</script>");
                if (Session["usertype"].ToString().Equals("admin"))
                {
                    vendorreg.ForeColor = System.Drawing.Color.White;
                    vendorreg.Visible = true;
                    adminreg.ForeColor = System.Drawing.Color.White;
                    adminreg.Visible = true;
                    VendorSearch.ForeColor = System.Drawing.Color.White;
                    VendorSearch.Visible = true;
                }
                else if (Session["usertype"].ToString().Equals("user"))
                {
                   // vendorreg.ForeColor = System.Drawing.Color.White;
                    vendorreg.Visible = false;
                    //adminreg.ForeColor = System.Drawing.Color.White;
                    adminreg.Visible = false;
                }
                else if (Session["usertype"].ToString().Equals("vendor"))
                {
                    // vendorreg.ForeColor = System.Drawing.Color.White;
                    vendorreg.Visible = false;
                    //adminreg.ForeColor = System.Drawing.Color.White;
                    adminreg.Visible = false;
                    searchLink.Visible = false;
                }
            }
            else
            {
                loggedin.Text = "sasas";
            }
        }
    }
}
