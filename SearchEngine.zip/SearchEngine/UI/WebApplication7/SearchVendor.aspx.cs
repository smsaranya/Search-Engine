﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;

namespace WebApplication7
{
    public partial class SearchVendor : System.Web.UI.Page
    {
        public SqlCommand Cmd = new SqlCommand();
        public SqlConnection cnn = new SqlConnection();
        string con_QSR = ConfigurationManager.ConnectionStrings["SearchEngineConnectionString"].ToString();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            try
            {
                String search_keyword_val = keyword.Text.Trim();
              
                cnn = new SqlConnection(con_QSR);
                cnn.Open();
                String qry;

                if (search_keyword_val == "" || search_keyword_val == "undefined" || search_keyword_val == null || search_keyword_val == "null")
                {
                    qry = "select * from SE_Vendor_Registration";
                }
                else
                {
                    // Response.Write("<script type=text/javascript>alert('test0');</script>");
                    qry = "select * from SE_Vendor_Registration where fname like '%"+ search_keyword_val+"%'";
                }
               

                SqlDataAdapter da = new SqlDataAdapter(qry, cnn);
                //DataTable dt = new DataTable();
                DataSet dt = new DataSet();
                da.Fill(dt);
                search_result.DataSource = dt;
                search_result.DataBind();
                search_result.ForeColor = System.Drawing.Color.Red;
                /* Cmd.Connection = cnn;
                 Cmd.CommandText = "select * from SE_User_Registration";
                 RepeatInformation.DataSource = Cmd.ExecuteReader();
                 RepeatInformation.DataBind();*/

                cnn.Close();

            }
            catch (Exception ex)
            {
                Response.Write("<script type=text/javascript>alert('" + ex.Message + "');</script>");
                cnn.Close();
            }
        }
        protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            search_result.PageIndex = e.NewPageIndex;
            //BindGrid();
        }

        protected void search_result_SelectedIndexChanged(object sender, EventArgs e)
        {
            Response.Write("<script type=text/javascript>alert('test');</script>");
        }
        protected void LinkButton1_Click(object sender, CommandEventArgs e)
        {
            Response.Write("<script type=text/javascript>alert('"+e.CommandArgument.ToString()+"');</script>");
            Response.Redirect("~/Vendor_Registration.aspx?email=" + e.CommandArgument.ToString() + "&mode=edit", false);
        }
    }
}