﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Text;


namespace WebApplication7
{
    public partial class Admin_Registration : System.Web.UI.Page
    {
        public SqlCommand Cmd = new SqlCommand();
        public SqlConnection cnn = new SqlConnection();
        string con_QSR = ConfigurationManager.ConnectionStrings["SearchEngineConnectionString"].ToString();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsubm_Click(object sender, EventArgs e)
        {
            try
            {

                String email_id = email.Text.Trim();
                String password = pass.Text.Trim();
                cnn = new SqlConnection(con_QSR);
                cnn.Open();
                String qry = "insert into SE_user_registration (email_id,password,created_by,created_on,updated_by,updated_on,custom0,custom1)  values('" + email_id + "','" + EnryptString(password) + "','" + email_id + "',GETDATE(),'','','','admin')";
                //Response.Write("<script type=text/javascript>alert('" + qry + "');</script>");
                Cmd = new SqlCommand(qry, cnn);
                Cmd.ExecuteNonQuery();
                // alert.ForeColor = System.Drawing.Color.Red;
                // alert.Text = "Record Saved Successfully";
                //CleartextBoxes1();
                cnn.Close();
                string message = "Your details have been saved successfully.";
                string script = "window.onload = function(){ alert('";
                script += message;
                script += "');";
                script += "window.location = '";
                script += Request.Url.AbsoluteUri;
                script += "'; }";
                ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);
                System.Threading.Thread.Sleep(2000);
            }
            catch (Exception)
            {
                //Response.Redirect("~/Error.html");
                alert.ForeColor = System.Drawing.Color.Red;
                alert.Text = "Problem in Inserting the Record";
            }


        }

        public string EnryptString(string strEncrypted)
        {
            byte[] b = System.Text.ASCIIEncoding.ASCII.GetBytes(strEncrypted);
            string encrypted = Convert.ToBase64String(b);
            return encrypted;
        }
        public string encrypt(string encryptString)
        {
            string EncryptionKey = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            byte[] clearBytes = Encoding.Unicode.GetBytes(encryptString);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] {
            0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76
        });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    encryptString = Convert.ToBase64String(ms.ToArray());
                }
            }
            return encryptString;
        }

    }
}