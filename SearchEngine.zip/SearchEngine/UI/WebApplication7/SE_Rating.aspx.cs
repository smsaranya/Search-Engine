﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.IO;

namespace WebApplication7
{
    public partial class SE_Rating : System.Web.UI.Page
    {
        public SqlCommand Cmd = new SqlCommand();
        public SqlConnection cnn = new SqlConnection();
        string id_val = "";
        string con_QSR = ConfigurationManager.ConnectionStrings["SearchEngineConnectionString"].ToString();
        protected void Page_Load(object sender, EventArgs e)
        {
            id_val = Request.QueryString["id"];
            vendor_id.Text = id_val;
            vendor_id.Visible = false;
            //Response.Write("<script type=text/javascript>alert('" + id_val + "');</script>");
            cnn = new SqlConnection(con_QSR);
            cnn.Open();
            String qry = "select * from SE_Vendor_Registration where id='" + id_val + "'";
            SqlCommand cmd = new SqlCommand(qry, cnn);
            SqlDataReader sdr = cmd.ExecuteReader();
            if (sdr.Read())
            {
                name.Text = sdr["honorific"].ToString() + "." + sdr["fname"].ToString() + " " + sdr["lname"].ToString();
                occupation.Text = sdr["occupation"].ToString();
                off_addr.Text = sdr["off_address"].ToString();
                mobilenum.Text = sdr["off_contact"].ToString();
                // Response.Redirect("~/Home.aspx", false); 
            }
            else
            {

                // alert.ForeColor = System.Drawing.Color.Red;
                // alert.Text = "Invalid Username or Password";
                // Session["login_status"] = false;

            }
            cnn.Close();

            if (Session["username"] != "" && Session["username"] != null)
            {

            }
            else
            {
                submit.Visible = false;
                ratinglabel.Visible = false;
                rate.Visible = false;
                commentslabel.Visible = false;
                comments.Visible = false;


            }
        }



        protected void submit_Click1(object sender, EventArgs e)
        {
            try
            {

                String rating = rate.Text.Trim();
                String comment = comments.Text.Trim();
                String VendorID = vendor_id.Text.Trim();
                //Response.Write("<script type=text/javascript>alert('" + rating + "');</script>");
                // Response.Write("<script type=text/javascript>alert('" + comment + "');</script>");
                cnn = new SqlConnection(con_QSR);
                cnn.Open();
                String qry = "insert into SE_Rating(vendor_id,rating,comments)  values('" + VendorID + "','" + rating + "','" + comment + "')";
                // Response.Write("<script type=text/javascript>alert('" + qry + "');</script>");

                Cmd = new SqlCommand(qry, cnn);
                Cmd.ExecuteNonQuery();
                alert.ForeColor = System.Drawing.Color.Red;
                alert.Text = "Record Saved Successfully";
                cnn.Close();


            }
            catch (Exception e3)
            {
                alert.ForeColor = System.Drawing.Color.Red;
                alert.Text = "Problem in Inserting the Record";

            }
        }
        protected void OpenWindow(object sender, EventArgs e)
        {
            string url = "ViewRating.aspx?id="+id_val;
            string s = "window.open('" + url + "', 'popup_window', 'width=800,height=500,left=100,top=100,resizable=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
    }
}